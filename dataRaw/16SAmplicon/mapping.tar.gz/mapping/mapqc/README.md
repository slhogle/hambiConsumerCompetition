# negCTRL1

This sample is a negative control sequenced without any bacterial DNA added.

There were only 148 reads that mapped to the bacterial community.

65 matched perfectly.

The remainder matched with very high error rate likely because of mismapping noise.

The presence of HAMBI synthetic community species in the negative control is likely due to [cross-talk between mutliplexed Illumina libraries.](https://www.biorxiv.org/content/10.1101/400762v1)