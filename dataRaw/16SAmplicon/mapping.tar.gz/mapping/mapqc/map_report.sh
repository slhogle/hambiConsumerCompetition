#!/usr/bin/env bash

printf '%s\n' * > files.txt
split -l 38 files.txt
ls xa* > dirs.txt

cat dirs.txt | while read id; do mkdir 16S_map_${id}; done
cat dirs.txt | while read id; do cat ${id} | parallel mv {} 16S_map_${id}; done

rm -rf xa*

cat dirs.txt | while read id; do multiqc -n 16S_map_${id} --no-data-dir -m bbmap,samtools 16S_map_${id}; done

cat dirs.txt | while read id; do tar -czvf 16S_map_${id}.tar.gz fastqc 16S_map_${id}; done

cat dirs.txt | while read id; do rm -rf 16S_map_${id}; done